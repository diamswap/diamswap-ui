// 


export const metadata = {
  tokens: [
    {
      symbol: "DIAM",
      name: "Tether",
      balance: "0",
      icon: "https://cryptologos.cc/logos/tether-usdt-logo.png?v=023", 
    },
    {
      symbol: "TRADE",
      name: "Dai",
      balance: "0",
      icon: "https://cryptologos.cc/logos/multi-collateral-dai-dai-logo.png?v=023", // Public URL for DAI icon
    },
  ],
};
